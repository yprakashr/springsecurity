import { Typography } from '@mui/material';
import React from 'react'

export default function Whdashboard() {
  return (
    <>
      <Typography
        sx={{
          color: "#303779",
          textAlign: "center",
          fontSize: "30px",
          fontFamily: "Montserrat-Bold",
          lineHeight:"380px"
        }}
      >
        Under Developing{" "}
      </Typography>
    </>
  );
}
