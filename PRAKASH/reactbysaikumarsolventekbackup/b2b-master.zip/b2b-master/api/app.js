const express = require('express');

const app = express();

module.exports = app;
