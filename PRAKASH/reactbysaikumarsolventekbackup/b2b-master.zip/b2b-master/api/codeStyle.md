# Do

1. use always camelCase in model
2. always use dao for database abstraction layer layer .mainly common dao
3. always put credentails in .env.

# Dont

1. dont use snake_case in db models for column
