from django.urls import path
from .views import register_user, user_login, user_logout, get_userdata, change_password, edit_user_info, upload_doc

urlpatterns = [
    path('register/', register_user, name='register'),
    path('login/', user_login, name='login'),
    path('logout/', user_logout, name='logout'),
    path('userdetails/', get_userdata, name='userdetails'),
    path('change_password/', change_password, name='change_password'),
    path('edit_user/<str:user_id>/', edit_user_info, name='edit_user'),
    path('upload_doc/', upload_doc, name='upload_doc'),
]