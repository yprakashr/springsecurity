from rest_framework import serializers
from .models import OTTUser

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = OTTUser
        fields = ['username', 'email', 'password']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = OTTUser(
            username=validated_data['username'],
            email=validated_data['email'],
        )
        user.set_password(validated_data['password'])
        user.save()
        return user

class UserLoginSerializer(serializers.ModelSerializer):
    class Meta:
        model = OTTUser
        fields = ['username', 'role']

class GetUserDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = OTTUser
        fields = ['id', 'username', 'email']

class UserEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = OTTUser
        fields = ['id', 'username', 'email']

class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

class ResetPasswordEmailSerializer(serializers.Serializer):
    email = serializers.EmailField(required=True)