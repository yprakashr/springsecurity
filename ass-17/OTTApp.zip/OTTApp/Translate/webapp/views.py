from rest_framework import status
from rest_framework.response import Response
from .serializers import UserSerializer, ChangePasswordSerializer, UserEditSerializer, GetUserDetailsSerializer, UserLoginSerializer
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate, update_session_auth_hash
from django.core.exceptions import ObjectDoesNotExist
from .models import OTTUser
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
# from django.http import JsonResponse
from docx import Document
import re
from googletrans import Translator
import json
from django.core import serializers

@api_view(['POST'])
def register_user(request):
    if request.method == 'POST':
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def user_login(request):
    if request.method == 'POST':
        username = request.data.get('username')
        password = request.data.get('password')

        user = None
        if '@' in username:
            try:
                user = OTTUser.objects.get(email=username)
            except ObjectDoesNotExist:
                pass

        if not user:
            user = authenticate(username=username, password=password)

        if user:
            token, _ = Token.objects.get_or_create(user=user)
            userott = OTTUser.objects.filter(username=user)
            data = UserLoginSerializer(userott, many=True).data
            # datab = serializers.serialize('json', data, fields=('username', 'role'))
            return Response({'data': data, 'token': token.key}, content_type="application/json", status=status.HTTP_200_OK)

        return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_userdata(request):
    if request.method == 'GET':
        user = OTTUser.objects.filter(role="user")
        data = GetUserDetailsSerializer(user, many=True).data
        return Response(data)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def user_logout(request):
    if request.method == 'POST':
        try:
            # Delete the user's token to logout
            request.user.auth_token.delete()
            return Response({'message': 'Successfully logged out.'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def change_password(request):
    if request.method == 'POST':
        serializer = ChangePasswordSerializer(data=request.data)
        if serializer.is_valid():
            user = request.user
            if user.check_password(serializer.data.get('old_password')):
                user.set_password(serializer.data.get('new_password'))
                user.save()
                update_session_auth_hash(request, user)  # To update session after password change
                return Response({'message': 'Password changed successfully.'}, status=status.HTTP_200_OK)
            return Response({'error': 'Incorrect old password.'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def edit_user_info(request, user_id):
    try:
        user = OTTUser.objects.get(id=user_id)
    except OTTUser.DoesNotExist:
        return Response({'message': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
    # user = request.user  # Get the authenticated user
    if request.method == 'PATCH':
        serializer = UserEditSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def upload_doc(request):
    if 'doc_file' in request.FILES:
        doc_file = request.FILES['doc_file']

        # Read data from the uploaded DOC file
        doc = Document(doc_file)
        translated_paragraphs_list = []

        for paragraph in doc.paragraphs:
            english_text = paragraph.text
            if english_text:
                if english_text.isnumeric():
                    pass
                elif not re.match(r'\d{2}:\d{2}:\d{2},\d{3} --> \d{2}:\d{2}:\d{2},\d{3}', english_text.strip()):
                    print('english text :', english_text)
                    translator = Translator()
                    translation = translator.translate(english_text, src='en', dest='te')
                    telugu_text = translation.text
                    print('telugu text :', telugu_text)
                    translated_paragraphs_dict = {}
                    translated_paragraphs_dict['english'] = english_text
                    translated_paragraphs_dict['telugu'] = telugu_text
                    translated_paragraphs_list.append(translated_paragraphs_dict)

        return Response({'success': True, 'data': translated_paragraphs_list})
    else:
        return Response({'success': False, 'error': 'No DOC file provided'})